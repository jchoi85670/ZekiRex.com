@echo off
rem Zekirex launcher (Windows). ASCII only on purpose: Korean text in .bat files breaks on some code pages.
cd /d "%~dp0"

set "PY="
py -3 -c "import sys" >nul 2>&1 && set "PY=py -3"
if not defined PY (python -c "import sys" >nul 2>&1 && set "PY=python")

if defined PY (
  echo Updating data...
  %PY% build.py
  if errorlevel 1 (
    echo Update failed. Opening the existing file instead.
    pause
  )
) else (
  echo Python not found. Opening the included file as is.
)

start "" "%~dp0zekirex.html"
