@echo off
cd /d "%~dp0"
python build.py
if errorlevel 1 (echo 파이썬이 필요합니다: https://www.python.org & pause & exit /b)
start "" platform.html
