"""prices/*.csv 를 읽어 오프라인용 단일 HTML(platform.html)을 만든다.

사용법:  python build.py            -> platform.html
         python build.py out.html   -> 지정한 파일명
"""
import csv
import json
import sys
from collections import deque
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PRICES_DIR = ROOT / "prices"
TEMPLATE = ROOT / "template.html"
PLACEHOLDER = "/*__DATA__*/"
BT_PLACEHOLDER = "/*__BACKTEST__*/"


def load_ticker(path: Path) -> dict:
    """CSV 하나를 컬럼별 배열로 읽는다. 고가/저가/종가가 빠진 행은 건너뛴다."""
    rows = []
    with path.open(newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            try:
                h, l, c = float(r["high"]), float(r["low"]), float(r["close"])
            except (KeyError, TypeError, ValueError):
                continue
            try:
                v = int(float(r.get("volume") or 0))
            except ValueError:
                v = 0
            rows.append((r["date"], h, l, c, v))
    rows.sort(key=lambda x: x[0])
    return {
        "d": [x[0] for x in rows],
        "h": [x[1] for x in rows],
        "l": [x[2] for x in rows],
        "c": [x[3] for x in rows],
        "v": [x[4] for x in rows],
    }


RS_LOOKBACK = 252   # 최근 1년 ≈ 252 거래일
YEAR = 252          # 52주 ≈ 252 거래일
MONTH = 21          # 1개월 ≈ 21 거래일


# ---------- 시계열 도우미 (i번째 값 = i번째 날까지의 창) ----------
def rolling_mean(a: list, p: int) -> list:
    out, s = [None] * len(a), 0.0
    for i, x in enumerate(a):
        s += x
        if i >= p:
            s -= a[i - p]
        if i >= p - 1:
            out[i] = s / p
    return out


def rolling_extreme(a: list, p: int, use_max: bool) -> list:
    """최근 p개 창의 최대(또는 최소). 단조 덱으로 O(n)."""
    out, dq = [None] * len(a), deque()
    better = (lambda x, y: x >= y) if use_max else (lambda x, y: x <= y)
    for i, x in enumerate(a):
        while dq and better(x, a[dq[-1]]):
            dq.pop()
        dq.append(i)
        if dq[0] <= i - p:
            dq.popleft()
        if i >= p - 1:
            out[i] = a[dq[0]]
    return out


def compute_rs_history(data: dict) -> dict:
    """날짜마다 '1년 수익률'로 전체 종목 백분위를 매긴 RS 점수(1~99) 이력.

    그 날짜에 1년치 데이터가 있는 종목끼리만 비교. 가장 낮은 종목 1, 가장 높은 종목 99.
    반환: {종목: [i번째 날 RS 점수 또는 None]}.  마지막 값이 오늘 RS 점수.
    """
    idx = {s: {d: i for i, d in enumerate(t["d"])} for s, t in data.items()}
    hist = {s: [None] * len(t["d"]) for s, t in data.items()}
    for date in sorted({d for t in data.values() for d in t["d"]}):
        rets = {}
        for s, t in data.items():
            i = idx[s].get(date)
            if i is not None and i >= RS_LOOKBACK and t["c"][i - RS_LOOKBACK] > 0:
                rets[s] = t["c"][i] / t["c"][i - RS_LOOKBACK] - 1
        m = len(rets)
        for rank, s in enumerate(sorted(rets, key=rets.get)):
            hist[s][idx[s][date]] = 1 + round(98 * rank / (m - 1)) if m > 1 else 99
    return hist


def trend_template_series(t: dict, rs_hist: list) -> tuple:
    """마크 미너비니 추세 템플릿 8개 조건을 매 거래일 검사한다.

    1. 종가 > 150일선, 종가 > 200일선
    2. 150일선 > 200일선
    3. 200일선이 최소 1개월(21거래일) 상승 중: 그날 200일선 > 21거래일 전 200일선
    4. 50일선 > 150일선, 50일선 > 200일선
    5. 종가 > 50일선
    6. 종가가 52주 최저가보다 30% 이상 위
    7. 종가가 52주 최고가 대비 25% 이내
    8. RS 점수 70 이상
    52주 최고/최저는 그날까지 252거래일 일봉의 고가/저가 기준.
    계산에 필요한 데이터가 부족한 조건은 통과하지 못한 것(False)으로 본다.
    반환: (날짜별 8개 조건 리스트, 마지막 날 참고값 dict)
    """
    c = t["c"]
    m50, m150, m200 = rolling_mean(c, 50), rolling_mean(c, 150), rolling_mean(c, 200)
    hi52 = rolling_extreme(t["h"], YEAR, True)
    lo52 = rolling_extreme(t["l"], YEAR, False)
    ok = lambda *v: all(x is not None for x in v)
    series = []
    for i, px in enumerate(c):
        a, b, d = m50[i], m150[i], m200[i]
        d1m = m200[i - MONTH] if i >= MONTH else None
        rs = rs_hist[i]
        series.append([
            ok(b, d) and px > b and px > d,
            ok(b, d) and b > d,
            ok(d, d1m) and d > d1m,
            ok(a, b, d) and a > b and a > d,
            ok(a) and px > a,
            ok(lo52[i]) and px >= lo52[i] * 1.30,
            ok(hi52[i]) and px >= hi52[i] * 0.75,
            rs is not None and rs >= 70,
        ])
    r = lambda v: None if v is None else round(v, 2)
    last = len(c) - 1
    info = {
        "m50": r(m50[last]), "m150": r(m150[last]), "m200": r(m200[last]),
        "m200_1m": r(m200[last - MONTH]) if last >= MONTH else None,
        # 52주 데이터가 모자라면 있는 만큼으로 참고값 표시 (판정은 위에서 False)
        "hi52": r(hi52[last] if hi52[last] is not None else max(t["h"])),
        "lo52": r(lo52[last] if lo52[last] is not None else min(t["l"])),
    }
    return series, info


# ---------- 매수/매도 신호 ----------
BREAKOUT_LOOKBACK = 50   # 직전 50일 최고가 돌파
VOL_LOOKBACK = 50        # 거래량 50일 평균
VOL_MULT = 1.5           # 평균의 1.5배 이상
TRAIL_STOP = 0.08        # 산 뒤 최고 종가 대비 -8%


def buy_condition(t: dict, all_pass: list) -> list:
    """날짜별 매수 조건 충족 여부.

    그날 추세 템플릿 8개 모두 통과
    & 종가 > 직전 50거래일(오늘 제외) 고가 중 최고
    & 거래량 >= 직전 50거래일(오늘 제외) 평균 거래량 x 1.5
    """
    c, v = t["c"], t["v"]
    hi_prev = rolling_extreme(t["h"], BREAKOUT_LOOKBACK, True)   # i-1 을 써서 오늘 제외
    vavg = rolling_mean(v, VOL_LOOKBACK)
    out = [False] * len(c)
    for i in range(1, len(c)):
        hp, va = hi_prev[i - 1], vavg[i - 1]
        out[i] = bool(all_pass[i] and hp is not None and va and c[i] > hp and v[i] >= va * VOL_MULT)
    return out


def find_signals(t: dict, buy_ok: list) -> list:
    """종목 하나만 놓고 (한 번에 한 포지션, 종가 체결) 차트에 표시할 매수/매도 신호를 찾는다.

    매수(보유 없음일 때): buy_condition 충족
    매도(보유 중일 때): 종가 <= 매수 후 최고 종가(매수일 포함) x (1 - 8%)
    반환: [인덱스, "B", 매수가] / [인덱스, "S", 매도가, 수익률%, 매수 후 최고 종가]
    """
    c = t["c"]
    sigs, holding, entry, peak = [], False, 0.0, 0.0
    for i in range(1, len(c)):
        if not holding:
            if buy_ok[i]:
                sigs.append([i, "B", c[i]])
                holding, entry, peak = True, c[i], c[i]
        else:
            peak = max(peak, c[i])
            if c[i] <= peak * (1 - TRAIL_STOP):
                sigs.append([i, "S", c[i], round((c[i] / entry - 1) * 100, 2), peak])
                holding = False
    return sigs


def add_indicators(data: dict) -> tuple:
    """RS 점수, 추세 템플릿, 매수/매도 신호를 각 종목 데이터에 붙인다.
    반환: (종목별 RS 이력, 종목별 날짜별 매수 조건) - 백테스트용"""
    rs_hist = compute_rs_history(data)
    buy_ok = {}
    for s, t in data.items():
        c = t["c"]
        t["rs"] = rs_hist[s][-1]
        t["ret1y"] = (round((c[-1] / c[-1 - RS_LOOKBACK] - 1) * 100, 2)
                      if len(c) > RS_LOOKBACK else None)
        series, info = trend_template_series(t, rs_hist[s])
        t["tt"] = {"pass": [bool(x) for x in series[-1]], **info}
        buy_ok[s] = buy_condition(t, [all(x) for x in series])
        t["sig"] = find_signals(t, buy_ok[s])
    return rs_hist, buy_ok


# ---------- 포트폴리오 백테스트 ----------
BT_START = "2022-01-01"
BT_CAPITAL = 100_000.0
BT_SLOTS = 5             # 동시에 최대 5종목, 종목당 총자산의 1/5
BENCH = "SPY"


def max_drawdown(series: list) -> float:
    peak, mdd = series[0], 0.0
    for x in series:
        peak = max(peak, x)
        mdd = min(mdd, x / peak - 1)
    return mdd


def backtest(data: dict, rs_hist: dict, buy_ok: dict) -> dict:
    """48종목 전체를 대상으로 한 포트폴리오 백테스트.

    - 기간: BT_START 이후 첫 거래일 ~ 마지막 거래일. 시작 시점엔 현금 100%.
    - 매일 종가에: (1) 보유 종목 매도 조건 검사 -> 매도, (2) 빈 자리만큼 매수.
    - 매수 금액: 그 시점 총자산(현금+보유 평가액)의 1/5. 현금이 모자라면 남은 현금만큼.
    - 같은 날 매수 후보가 빈 자리보다 많으면 그날 RS 점수가 높은 순(같으면 티커순).
    - 보유 중이 아닌 종목은 매일 매수 조건을 다시 본다 (자리가 없어 놓친 돌파도
      다음 날 조건이 여전히 맞으면 매수).
    - 체결은 신호 당일 종가, 수수료/슬리피지/배당 없음, 소수점 주식 허용.
    - 끝날 때 보유 중인 종목은 마지막 종가로 평가 (거래 목록엔 '보유 중').
    """
    cal_src = data[BENCH]["d"] if BENCH in data else sorted({d for t in data.values() for d in t["d"]})
    cal = [d for d in cal_src if d >= BT_START]
    idx = {s: {d: i for i, d in enumerate(t["d"])} for s, t in data.items()}

    cash, pos, trades, equity, held = BT_CAPITAL, {}, [], [], []
    for d in cal:
        # 보유 종목 평가가격 갱신 + 매도
        for s in sorted(pos):
            p, i = pos[s], idx[s].get(d)
            if i is None:
                continue
            px = data[s]["c"][i]
            p["last"] = px
            p["peak"] = max(p["peak"], px)
            if px <= p["peak"] * (1 - TRAIL_STOP):
                cash += p["shares"] * px
                trades.append({**p, "exit_date": d, "exit": px, "open": False})
                del pos[s]
        # 매수
        cands = []
        for s in data:
            i = idx[s].get(d)
            if s not in pos and i is not None and buy_ok[s][i]:
                cands.append((-(rs_hist[s][i] or 0), s, i))
        for _, s, i in sorted(cands):
            if len(pos) >= BT_SLOTS:
                break
            total = cash + sum(p["shares"] * p["last"] for p in pos.values())
            amt = min(total / BT_SLOTS, cash)
            if amt <= 1e-9:
                break
            px = data[s]["c"][i]
            cash -= amt
            pos[s] = {"sym": s, "entry_date": d, "entry": px, "shares": amt / px,
                      "cost": amt, "peak": px, "last": px, "entry_i": i}
        equity.append(cash + sum(p["shares"] * p["last"] for p in pos.values()))
        held.append(len(pos))
    for s in sorted(pos):
        p = pos[s]
        trades.append({**p, "exit_date": None, "exit": p["last"], "open": True})

    # 거래 목록 정리
    out_trades = []
    for tr in sorted(trades, key=lambda x: (x["entry_date"], x["sym"])):
        s = tr["sym"]
        exit_i = idx[s][tr["exit_date"]] if tr["exit_date"] else len(data[s]["d"]) - 1
        out_trades.append({
            "sym": s, "in": tr["entry_date"], "inPx": round(tr["entry"], 2),
            "out": tr["exit_date"], "outPx": round(tr["exit"], 2),
            "ret": round((tr["exit"] / tr["entry"] - 1) * 100, 2),
            "pnl": round(tr["shares"] * tr["exit"] - tr["cost"], 2),
            "cost": round(tr["cost"], 2),
            "days": exit_i - tr["entry_i"], "open": tr["open"],
        })

    closed = [t for t in out_trades if not t["open"]]
    wins = [t for t in closed if t["ret"] > 0]
    losses = [t for t in closed if t["ret"] <= 0]
    years = (date.fromisoformat(cal[-1]) - date.fromisoformat(cal[0])).days / 365.25
    cagr = lambda r: (1 + r) ** (1 / years) - 1 if years > 0 else 0.0
    avg = lambda xs: round(sum(xs) / len(xs), 2) if xs else None

    stats = {
        "start": cal[0], "end": cal[-1], "capital": BT_CAPITAL, "slots": BT_SLOTS,
        "final": round(equity[-1], 2),
        "totalRet": round((equity[-1] / BT_CAPITAL - 1) * 100, 2),
        "cagr": round(cagr(equity[-1] / BT_CAPITAL - 1) * 100, 2),
        "mdd": round(max_drawdown(equity) * 100, 2),
        "trades": len(out_trades), "closed": len(closed), "openN": len(out_trades) - len(closed),
        "wins": len(wins),
        "winRate": round(len(wins) / len(closed) * 100, 2) if closed else None,
        "avgRet": avg([t["ret"] for t in closed]),
        "avgWin": avg([t["ret"] for t in wins]), "avgLoss": avg([t["ret"] for t in losses]),
        "avgDays": avg([t["days"] for t in closed]),
        "exposure": round(sum(held) / (len(held) * BT_SLOTS) * 100, 1),
    }
    bench = None
    if BENCH in data:
        bc = [data[BENCH]["c"][idx[BENCH][d]] for d in cal]
        b_ret = bc[-1] / bc[0] - 1
        bench = [round(x / bc[0] * BT_CAPITAL, 2) for x in bc]
        stats.update({"benchTotalRet": round(b_ret * 100, 2), "benchCagr": round(cagr(b_ret) * 100, 2),
                      "benchMdd": round(max_drawdown(bc) * 100, 2)})
    return {"stats": stats, "dates": cal, "equity": [round(x, 2) for x in equity],
            "bench": bench, "benchSym": BENCH, "trades": out_trades}


def build(out_path: Path) -> tuple:
    data = {}
    for p in sorted(PRICES_DIR.glob("*.csv")):
        t = load_ticker(p)
        if t["d"]:
            data[p.stem.upper()] = t
    if not data:
        raise SystemExit(f"{PRICES_DIR} 에서 읽을 데이터가 없습니다.")
    rs_hist, buy_ok = add_indicators(data)
    bt = backtest(data, rs_hist, buy_ok)

    # </script> 로 스크립트 블록이 끊기지 않도록 "</" 를 이스케이프
    dump = lambda o: json.dumps(o, separators=(",", ":")).replace("</", "<\\/")
    html = TEMPLATE.read_text(encoding="utf-8")
    for ph in (PLACEHOLDER, BT_PLACEHOLDER):
        if ph not in html:
            raise SystemExit(f"template.html 에 자리표시자 {ph} 가 없습니다.")
    html = html.replace(PLACEHOLDER, dump(data)).replace(BT_PLACEHOLDER, dump(bt))
    out_path.write_text(html, encoding="utf-8")
    return data, bt


if __name__ == "__main__":
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "platform.html"
    data, bt = build(out)
    bars = sum(len(t["d"]) for t in data.values())
    print(f"{out.name}: 종목 {len(data)}개, 일봉 {bars:,}개, {out.stat().st_size / 1e6:.2f} MB")
    passed = [s for s, t in data.items() if all(t["tt"]["pass"])]
    print(f"추세 템플릿 8개 조건 모두 통과: {len(passed)}개 {sorted(passed)}")
    sigs = [x for t in data.values() for x in t["sig"]]
    holding = sorted(s for s, t in data.items() if t["sig"] and t["sig"][-1][1] == "B")
    print(f"신호: 매수 {sum(x[1] == 'B' for x in sigs)}회, 매도 {sum(x[1] == 'S' for x in sigs)}회, "
          f"현재 보유 중 {holding}")
    st = bt["stats"]
    print(f"백테스트 {st['start']}~{st['end']}: 총수익률 {st['totalRet']:+.2f}% (SPY {st.get('benchTotalRet', 0):+.2f}%), "
          f"승률 {st['winRate']}% ({st['wins']}/{st['closed']}), MDD {st['mdd']}% (SPY {st.get('benchMdd')}%), "
          f"거래 {st['trades']}건 (보유 중 {st['openN']})")
