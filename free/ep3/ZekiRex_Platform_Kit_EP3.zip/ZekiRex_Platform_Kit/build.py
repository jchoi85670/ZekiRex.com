#!/usr/bin/env python3
"""prices/*.csv 를 읽어 오프라인으로 열리는 단일 HTML 트레이딩 화면(zekirex.html)을 만든다.

사용법:  python3 build.py [--prices prices] [--out zekirex.html]
표준 라이브러리만 사용한다.
"""
import argparse
import csv
import json
import sys
from pathlib import Path


def load_csv(path: Path) -> dict:
    """CSV 한 파일을 열 단위 배열로 읽는다. 잘못된 행은 건너뛰고 개수를 센다."""
    rows = []
    skipped = 0
    open_off = 0
    with path.open(newline="") as f:
        for r in csv.DictReader(f):
            try:
                d = r["date"].strip()
                o, h, l, c = float(r["open"]), float(r["high"]), float(r["low"]), float(r["close"])
                v = float(r["volume"]) if r.get("volume") else 0.0
            except (KeyError, ValueError):
                skipped += 1
                continue
            if h < l or not (l <= c <= h):
                skipped += 1
                continue
            # 시가가 고가~저가를 살짝 벗어나는 행은 데이터 업체 간 집계 차이라 그대로 두고 개수만 센다
            if not (l <= o <= h):
                open_off += 1
            rows.append((d, o, h, l, c, v))

    rows.sort(key=lambda x: x[0])
    # 같은 날짜가 중복되면 마지막 것만 남긴다
    dedup = {}
    for row in rows:
        dedup[row[0]] = row
    rows = list(dedup.values())

    return {
        "d": [r[0] for r in rows],
        "o": [round(r[1], 4) for r in rows],
        "h": [round(r[2], 4) for r in rows],
        "l": [round(r[3], 4) for r in rows],
        "c": [round(r[4], 4) for r in rows],
        "v": [int(r[5]) for r in rows],
        "skipped": skipped,
        "open_off": open_off,
    }


def build(prices_dir: Path, out: Path) -> None:
    files = sorted(prices_dir.glob("*.csv"))
    if not files:
        sys.exit(f"CSV 파일이 없습니다: {prices_dir}")

    data = {}
    for f in files:
        series = load_csv(f)
        skipped = series.pop("skipped")
        open_off = series.pop("open_off")
        if open_off:
            print(f"  참고: {f.name} 에서 시가가 고가~저가 범위를 벗어난 행 {open_off}개 (그대로 사용)")
        if not series["d"]:
            print(f"  경고: {f.name} 에 유효한 행이 없어 제외합니다")
            continue
        if skipped:
            print(f"  경고: {f.name} 에서 잘못된 행 {skipped}개를 건너뛰었습니다")
        data[f.stem.upper()] = series

    payload = json.dumps(data, separators=(",", ":"))
    # <script> 안에 넣을 때 태그가 닫히지 않도록 이스케이프
    payload = payload.replace("</", "<\\/")

    template = (Path(__file__).parent / "template.html").read_text(encoding="utf-8")
    html = template.replace("/*__DATA__*/", payload)
    out.write_text(html, encoding="utf-8")

    print(f"{len(data)}개 종목 → {out.name} ({out.stat().st_size / 1e6:.2f} MB)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    here = Path(__file__).resolve().parent   # 어느 폴더에서 실행해도 스크립트 옆 파일을 쓴다
    ap.add_argument("--prices", default=here / "prices", type=Path)
    ap.add_argument("--out", default=here / "zekirex.html", type=Path)
    a = ap.parse_args()
    build(a.prices, a.out)
