==============================================
 ZekiRex™ 플랫폼 키트 — EP3 「Claude Code로 나만의 트레이딩 플랫폼」
==============================================

유튜브 ZekiRex™ EP3에서 실제로 만든 코드 전체입니다. 무료로 쓰세요.
코드는 한 줄도 사람이 쓰지 않았고, Claude Code에게 한국어로 요청해서 만들었습니다.

■ 들어 있는 것
- template.html : 화면 코드 (HLC 바 차트, 이동평균, 거래량, RS, 스크리너, 신호, 백테스트, 라이트/다크 테마)
- build.py      : prices 폴더의 CSV를 읽고 백테스트까지 계산해 platform.html 하나로 만드는 프로그램 (파이썬 3, 표준 라이브러리만)
- analysis/audit.py         : 「좋은 것만 골랐나?」 검증 — 그냥 보유와 비교, 연도별 성적, 최악의 거래, 상위 종목 제외, 다음 날 시가 체결
- analysis/compare_rules.py : 내 규칙 비교 (손절·돌파 기간을 바꿔 나란히 비교)
- Start-Mac.command / Start-Windows.bat : 더블클릭 실행 파일
- prices/       : 비어 있습니다. 여기에 주가 데이터를 넣으세요 (아래 참고)
- 요청문장.txt   : 영상에서 Claude Code에게 한 요청 11개

■ 가격 데이터는 왜 없나요?
데이터 업체 약관상 다시 나눠 드릴 수 없어서 뺐습니다. CSV 형식만 맞추면 어떤 종목이든 됩니다.
- 파일 이름: 종목코드.csv (예: AAPL.csv) · 첫 줄: date,open,high,low,close,volume · 날짜: 2026-11-16
- SPY.csv 는 꼭 넣으세요 (RS선과 백테스트의 기준). analysis/audit.py 를 쓰려면 QQQ.csv 도 넣으세요
받은 곳의 이용 약관은 꼭 확인하세요.

■ 실행
1) prices 폴더에 CSV를 넣는다
2) Start-Mac.command / Start-Windows.bat 더블클릭 (또는 터미널에서 python3 build.py)
3) 생긴 platform.html 이 브라우저로 열린다
검증까지 직접 해 보려면:  python3 analysis/audit.py

■ 꼭 읽어 주세요 (면책)
- 이 키트와 영상은 교육용입니다. 투자 권유나 투자 자문이 아닙니다.
- 백테스트는 배당·수수료·세금·슬리피지를 빼지 않은 계산이며, 과거 결과가 미래 수익을 보장하지 않습니다.
- 종목 목록을 지금 시점에 고르면 결과가 실제보다 좋아 보일 수 있습니다(선정 편향). audit.py 로 직접 확인하세요.
- 매수·매도 규칙은 널리 알려진 교과서 규칙을 예시로 쓴 것입니다.
- 코드는 있는 그대로(AS IS) 제공되며, 사용에 따른 책임은 사용자에게 있습니다.

ZekiRex™ · https://zekirex.com
