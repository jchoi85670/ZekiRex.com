"""백테스트 정직성 검증 (앱/배포판은 건드리지 않음, build.py 함수만 import).

사용법: python analysis/audit.py
"""
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import build  # noqa: E402

B = build


def load_all():
    data = {}
    for p in sorted(B.PRICES_DIR.glob("*.csv")):
        t = B.load_ticker(p)
        # load_ticker 는 open 을 안 읽으므로 따로 읽는다
        import csv
        opens = {}
        with p.open(newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                try:
                    opens[r["date"]] = float(r["open"])
                except (KeyError, TypeError, ValueError):
                    pass
        t["o"] = [opens.get(d, c) for d, c in zip(t["d"], t["c"])]
        data[p.stem.upper()] = t
    return data


def strip(data):
    """build.add_indicators 가 붙이는 키 외에 'o' 도 보존한 사본"""
    return {s: {k: list(v) for k, v in t.items() if k in "dhlcvo"} for s, t in data.items()}


def cagr(r, d0, d1):
    y = (date.fromisoformat(d1) - date.fromisoformat(d0)).days / 365.25
    return (1 + r) ** (1 / y) - 1


def yearly(dates, eq):
    out, prev_end = {}, eq[0]
    # 첫해는 시작값 대비
    years = sorted({d[:4] for d in dates})
    for y in years:
        idx = [i for i, d in enumerate(dates) if d[:4] == y]
        end = eq[idx[-1]]
        out[y] = end / prev_end - 1
        prev_end = end
    return out


def year_mdd(dates, eq):
    out = {}
    for y in sorted({d[:4] for d in dates}):
        s = [eq[i] for i, d in enumerate(dates) if d[:4] == y]
        out[y] = B.max_drawdown(s)
    return out


def buy_hold(data, cal, syms):
    """cal[0] 종가에 종목별 같은 금액 매수, 이후 아무것도 안 함.
    아직 상장 전인 종목(GEV)은 상장 첫날 종가에 매수할 때까지 해당 금액을 현금으로 보유."""
    idx = {s: {d: i for i, d in enumerate(data[s]["d"])} for s in syms}
    per = B.BT_CAPITAL / len(syms)
    shares, cash, last = {}, {s: per for s in syms}, {}
    eq = []
    for d in cal:
        tot = 0.0
        for s in syms:
            i = idx[s].get(d)
            if i is not None:
                px = data[s]["c"][i]
                last[s] = px
                if s not in shares:
                    shares[s] = cash[s] / px
                    cash[s] = 0.0
            tot += cash[s] + shares.get(s, 0.0) * last.get(s, 0.0)
        eq.append(tot)
    return eq


def backtest_next_open(data, rs_hist, buy_ok):
    """build.backtest 와 같은 규칙이되, 신호는 당일 종가로 판단하고 체결은 다음 거래일 시가.
    - 매도: 종가 <= 최고종가 x 0.92 이면 다음 날 시가에 매도
    - 매수: 그날 매수 조건 충족 + (다음 날 매도 예정분 포함) 빈 자리 -> 다음 날 시가에 매수
      금액 = 다음 날 시가 기준 총자산의 1/5 (현금 한도). 후보 우선순위는 신호일 RS.
    - 최고가 추적은 체결가(시가)에서 시작해 이후 종가로 갱신
    """
    cal = [d for d in data[B.BENCH]["d"] if d >= B.BT_START]
    idx = {s: {d: i for i, d in enumerate(t["d"])} for s, t in data.items()}
    cash, pos, trades, equity = B.BT_CAPITAL, {}, [], []
    pend_sell, pend_buy = set(), []
    gaps = []
    for d in cal:
        # 1) 시가 체결: 매도 -> 매수
        for s in sorted(pend_sell):
            i = idx[s].get(d)
            if i is None:
                continue  # 거래 없는 날이면 다음 날로 미룸
            p = pos.pop(s)
            px = data[s]["o"][i]
            cash += p["shares"] * px
            trades.append({**p, "exit_date": d, "exit": px, "open": False, "exit_i": i})
            pend_sell.discard(s)
        if pend_buy:
            val = lambda s, p: data[s]["o"][idx[s][d]] if d in idx[s] else p["last"]
            for s, sig_px in pend_buy:
                i = idx[s].get(d)
                if i is None or s in pos or len(pos) >= B.BT_SLOTS:
                    continue
                total = cash + sum(p["shares"] * val(k, p) for k, p in pos.items())
                amt = min(total / B.BT_SLOTS, cash)
                if amt <= 1e-9:
                    break
                px = data[s]["o"][i]
                gaps.append(px / sig_px - 1)
                cash -= amt
                pos[s] = {"sym": s, "entry_date": d, "entry": px, "shares": amt / px,
                          "cost": amt, "peak": px, "last": px, "entry_i": i}
            pend_buy = []
        # 2) 종가: 평가 + 신호 판단
        for s in sorted(pos):
            p, i = pos[s], idx[s].get(d)
            if i is None:
                continue
            px = data[s]["c"][i]
            p["last"] = px
            p["peak"] = max(p["peak"], px)
            if px <= p["peak"] * (1 - B.TRAIL_STOP):
                pend_sell.add(s)
        free = B.BT_SLOTS - (len(pos) - len(pend_sell))
        cands = []
        for s in data:
            i = idx[s].get(d)
            if s not in pos and i is not None and buy_ok[s][i]:
                cands.append((-(rs_hist[s][i] or 0), s, data[s]["c"][i]))
        pend_buy = [(s, px) for _, s, px in sorted(cands)[:max(free, 0)]]
        equity.append(cash + sum(p["shares"] * p["last"] for p in pos.values()))
    for s in sorted(pos):
        p = pos[s]
        trades.append({**p, "exit_date": None, "exit": p["last"], "open": True,
                       "exit_i": len(data[s]["d"]) - 1})
    out = []
    for tr in trades:
        out.append({"sym": tr["sym"], "in": tr["entry_date"], "inPx": tr["entry"],
                    "out": tr["exit_date"], "outPx": tr["exit"],
                    "ret": (tr["exit"] / tr["entry"] - 1) * 100,
                    "pnl": tr["shares"] * tr["exit"] - tr["cost"],
                    "days": tr["exit_i"] - tr["entry_i"], "open": tr["open"]})
    return cal, equity, out, gaps


def trade_stats(trades):
    closed = [t for t in trades if not t["open"]]
    wins = [t for t in closed if t["ret"] > 0]
    avg = lambda xs: sum(xs) / len(xs) if xs else float("nan")
    return {"n": len(trades), "closed": len(closed), "win": len(wins) / len(closed) * 100,
            "avgRet": avg([t["ret"] for t in closed]),
            "avgWin": avg([t["ret"] for t in wins]),
            "avgLoss": avg([t["ret"] for t in closed if t["ret"] <= 0])}


def run_strategy(data, exclude=()):
    d = {s: t for s, t in strip(data).items() if s not in exclude}
    rs, ok = B.add_indicators(d)
    return B.backtest(d, rs, ok)


def line(name, eq, d0, d1):
    r = eq[-1] / eq[0] - 1
    return f"| {name} | {r*100:+.1f}% | {cagr(r, d0, d1)*100:+.1f}% | {B.max_drawdown(eq)*100:.1f}% |"


def main():
    raw = load_all()
    data = strip(raw)
    rs_hist, buy_ok = B.add_indicators(data)
    bt = B.backtest(data, rs_hist, buy_ok)
    cal, eq = bt["dates"], bt["equity"]
    d0, d1 = cal[0], cal[-1]
    all_syms = sorted(raw)
    stocks = [s for s in all_syms if s not in ("SPY", "QQQ")]
    bh48 = buy_hold(raw, cal, all_syms)
    bh46 = buy_hold(raw, cal, stocks)
    spy = bt["bench"]
    qqq = buy_hold(raw, cal, ["QQQ"])
    cal2, eq_no, tr_no, gaps = backtest_next_open(data, rs_hist, buy_ok)

    print(f"기간 {d0} ~ {d1}, 종목 {len(all_syms)}개 (ETF 2개 포함)\n")
    print("## ② 비교표 (배당 미포함, 수수료/슬리피지 없음)")
    print("| 방식 | 총수익률 | 연평균(CAGR) | 최대낙폭(MDD) |\n|---|---|---|---|")
    print(line("전략 (신호일 종가 체결, 현재 앱)", eq, d0, d1))
    print(line("전략 (다음 날 시가 체결)", eq_no, d0, d1))
    print(line("48종목 같은 금액 매수 후 보유", bh48, d0, d1))
    print(line("46개 개별주만 같은 금액 보유", bh46, d0, d1))
    print(line("SPY 보유", spy, d0, d1))
    print(line("QQQ 보유", qqq, d0, d1))

    # 종목별 B&H 수익률 (상위 집중도)
    rets = {}
    for s in all_syms:
        t = raw[s]
        i0 = next(i for i, d in enumerate(t["d"]) if d >= d0)
        rets[s] = t["c"][-1] / t["c"][i0] - 1
    srt = sorted(rets.items(), key=lambda x: -x[1])
    print("\n종목별 보유 수익률 상위 10:", ", ".join(f"{s} {r*100:+.0f}%" for s, r in srt[:10]))
    print("종목별 보유 수익률 하위 10:", ", ".join(f"{s} {r*100:+.0f}%" for s, r in srt[-10:]))
    med = sorted(rets[s] for s in stocks)[len(stocks) // 2]
    print(f"46개 개별주 중앙값 {med*100:+.0f}%, 손실 종목 {sum(rets[s] < 0 for s in stocks)}개, "
          f"SPY {rets['SPY']*100:+.0f}% 보다 나은 종목 {sum(rets[s] > rets['SPY'] for s in stocks)}개")

    # 전략 수익의 종목 집중도
    by_sym = {}
    for t in bt["trades"]:
        by_sym[t["sym"]] = by_sym.get(t["sym"], 0) + t["pnl"]
    tot_pnl = sum(by_sym.values())
    top = sorted(by_sym.items(), key=lambda x: -x[1])
    print(f"\n전략 총손익 ${tot_pnl:,.0f}; 종목별 기여 상위:",
          ", ".join(f"{s} ${v:,.0f}" for s, v in top[:8]))
    print("종목별 기여 하위:", ", ".join(f"{s} ${v:,.0f}" for s, v in top[-5:]))

    # 생존자 편향 민감도: 사후적으로 대박난 종목 빼고 다시 돌리기
    print("\n## ① 민감도: 사후 대박 종목 제외 후 재실행 (RS 순위도 남은 종목끼리 다시 계산)")
    print("| 제외 | 전략 총수익 | 전략 MDD | 같은 종목 B&H 총수익 | B&H MDD |\n|---|---|---|---|---|")
    winners_bh = [s for s, _ in srt if s not in ("SPY", "QQQ")]
    winners_pnl = [s for s, _ in top]
    for label, ex in [("없음", []),
                      ("B&H 상위 5", winners_bh[:5]),
                      ("B&H 상위 10", winners_bh[:10]),
                      ("전략 기여 상위 3", winners_pnl[:3]),
                      ("전략 기여 상위 5", winners_pnl[:5])]:
        r = run_strategy(raw, ex)
        bh = buy_hold(raw, cal, [s for s in all_syms if s not in ex])
        st = r["stats"]
        print(f"| {label} {','.join(ex)} | {st['totalRet']:+.1f}% | {st['mdd']:.1f}% | "
              f"{(bh[-1]/bh[0]-1)*100:+.1f}% | {B.max_drawdown(bh)*100:.1f}% |")

    print("\n## ③ 연도별 수익률 (괄호: 그해 안의 최대낙폭)")
    series = [("전략(종가)", cal, eq), ("전략(다음날 시가)", cal2, eq_no),
              ("48종목 B&H", cal, bh48), ("SPY", cal, spy)]
    ys = {n: (yearly(c, e), year_mdd(c, e)) for n, c, e in series}
    print("| 연도 | " + " | ".join(n for n, _, _ in series) + " |")
    print("|---|" + "---|" * len(series))
    for y in sorted(ys["SPY"][0]):
        lab = y + (" (~11/16)" if y == d1[:4] else "")
        print(f"| {lab} | " + " | ".join(f"{ys[n][0][y]*100:+.1f}% ({ys[n][1][y]*100:.0f}%)"
                                          for n, _, _ in series) + " |")
    ntr = {}
    for t in bt["trades"]:
        y = (t["out"] or d1)[:4]
        ntr.setdefault(y, [0, 0])
        if not t["open"]:
            ntr[y][0] += 1
            ntr[y][1] += t["ret"] > 0
    print("청산 연도별 거래수/승: " + ", ".join(f"{y}: {a}건 {b}승" for y, (a, b) in sorted(ntr.items())))

    print("\n## ③ 손실이 가장 컸던 거래 5개 (현재 앱 기준, 금액순)")
    print("| 종목 | 매수일 | 매수가 | 매도일 | 매도가 | 수익률 | 손익 | 보유일 |\n|---|---|---|---|---|---|---|---|")
    for t in sorted(bt["trades"], key=lambda x: x["pnl"])[:5]:
        print(f"| {t['sym']} | {t['in']} | {t['inPx']} | {t['out'] or '보유중'} | {t['outPx']} | "
              f"{t['ret']:+.2f}% | ${t['pnl']:,.0f} | {t['days']} |")
    print("\n(수익률순 하위 5)")
    for t in sorted(bt["trades"], key=lambda x: x["ret"])[:5]:
        print(f"| {t['sym']} | {t['in']} | {t['inPx']} | {t['out'] or '보유중'} | {t['outPx']} | "
              f"{t['ret']:+.2f}% | ${t['pnl']:,.0f} | {t['days']} |")

    print("\n## ④ 체결 방식 비교")
    s1, s2 = trade_stats(bt["trades"]), trade_stats(tr_no)
    print("| 항목 | 신호일 종가 | 다음 날 시가 |\n|---|---|---|")
    for k, lab in [("n", "거래 수"), ("closed", "청산 거래"), ("win", "승률%"), ("avgRet", "평균 수익률%"),
                   ("avgWin", "평균 이익%"), ("avgLoss", "평균 손실%")]:
        print(f"| {lab} | {s1[k]:.2f} | {s2[k]:.2f} |")
    g = sorted(gaps)
    print(f"매수 시 신호 종가 대비 다음 날 시가 갭: 평균 {sum(g)/len(g)*100:+.2f}%, "
          f"중앙값 {g[len(g)//2]*100:+.2f}%, 최저 {g[0]*100:+.1f}%, 최고 {g[-1]*100:+.1f}%")
    print("다음 날 시가 기준 최대 손실 거래 5개:")
    for t in sorted(tr_no, key=lambda x: x["pnl"])[:5]:
        print(f"  {t['sym']} {t['in']} {t['inPx']:.2f} -> {t['out'] or '보유중'} {t['outPx']:.2f} "
              f"{t['ret']:+.2f}% ${t['pnl']:,.0f}")


if __name__ == "__main__":
    main()
