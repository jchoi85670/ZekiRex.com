"""규칙 변경 비교 (build.py / platform.html / dist 는 건드리지 않음).

build.py 의 상수를 메모리에서만 바꿔 백테스트를 다시 돌린다.
사용법: python analysis/compare_rules.py
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import build as B  # noqa: E402

CONFIGS = [
    ("원래 (손절 8%, 돌파 50일)", 0.08, 50),
    ("손절만 7%", 0.07, 50),
    ("돌파만 20일", 0.08, 20),
    ("내 규칙 (손절 7%, 돌파 20일)", 0.07, 20),
]


def load():
    data = {}
    for p in sorted(B.PRICES_DIR.glob("*.csv")):
        t = B.load_ticker(p)
        if t["d"]:
            data[p.stem.upper()] = t
    return data


def run(stop, lookback):
    B.TRAIL_STOP, B.BREAKOUT_LOOKBACK = stop, lookback
    data = load()
    rs_hist, buy_ok = B.add_indicators(data)
    bt = B.backtest(data, rs_hist, buy_ok)
    eq, dates = bt["equity"], bt["dates"]
    yearly, prev = {}, B.BT_CAPITAL
    for y in sorted({d[:4] for d in dates}):
        end = eq[max(i for i, d in enumerate(dates) if d[:4] == y)]
        yearly[y] = (end / prev - 1) * 100
        prev = end
    return bt["stats"], yearly


def main():
    res = [(name, *run(s, lb)) for name, s, lb in CONFIGS]
    rows = [
        ("최종 자산($)", lambda s: f"{s['final']:,.0f}"),
        ("총수익률", lambda s: f"{s['totalRet']:+.2f}%"),
        ("연평균(CAGR)", lambda s: f"{s['cagr']:+.2f}%"),
        ("최대낙폭(MDD)", lambda s: f"{s['mdd']:.2f}%"),
        ("거래 수(보유중)", lambda s: f"{s['trades']} ({s['openN']})"),
        ("승률", lambda s: f"{s['winRate']}% ({s['wins']}/{s['closed']})"),
        ("평균 수익률/거래", lambda s: f"{s['avgRet']:+.2f}%"),
        ("평균 이익", lambda s: f"{s['avgWin']:+.2f}%"),
        ("평균 손실", lambda s: f"{s['avgLoss']:+.2f}%"),
        ("평균 보유일", lambda s: f"{s['avgDays']}"),
        ("자리 사용률", lambda s: f"{s['exposure']}%"),
    ]
    print("| 항목 | " + " | ".join(r[0] for r in res) + " |")
    print("|---|" + "---:|" * len(res))
    for label, f in rows:
        print(f"| {label} | " + " | ".join(f(r[1]) for r in res) + " |")
    for y in res[0][2]:
        print(f"| {y}년 수익률 | " + " | ".join(f"{r[2][y]:+.2f}%" for r in res) + " |")
    s = res[0][1]
    print(f"\n기간 {s['start']}~{s['end']}, SPY 총수익률 {s['benchTotalRet']:+.2f}%, "
          f"CAGR {s['benchCagr']:+.2f}%, MDD {s['benchMdd']:.2f}%")


if __name__ == "__main__":
    main()
