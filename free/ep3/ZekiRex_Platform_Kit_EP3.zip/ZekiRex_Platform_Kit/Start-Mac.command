#!/bin/bash
cd "$(dirname "$0")"
python3 build.py && open platform.html
