#!/bin/bash
# Zekirex 실행 (맥): 파이썬이 있으면 prices 폴더의 최신 데이터로 화면을 다시 만들고, 브라우저로 연다.
cd "$(dirname "$0")" || exit 1

# 파이썬 찾기. 맥 기본 /usr/bin/python3 은 개발자 도구가 없으면 설치 창을 띄우므로 그때는 건너뛴다.
PY="$(command -v python3 2>/dev/null)"
if [ "$PY" = "/usr/bin/python3" ] && ! xcode-select -p >/dev/null 2>&1; then
  PY=""
fi

if [ -n "$PY" ]; then
  echo "데이터를 반영하는 중..."
  if ! "$PY" build.py; then
    echo "데이터 반영에 실패했습니다. 기존 화면을 엽니다."
  fi
else
  echo "파이썬이 없어 들어 있는 화면 파일을 그대로 엽니다."
fi

open "zekirex.html"
echo "브라우저에서 열렸습니다. 이 창은 닫아도 됩니다."
